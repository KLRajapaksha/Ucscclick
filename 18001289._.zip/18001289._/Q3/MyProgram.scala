object MyProgram {
	def main(args:Array[String])
	{


		var m=new account("123",1000,25000);
		var n=new account("124",1001,10000);
		val bank:List[account]=List(m,n);
		
		val x=find(1001,bank);
		m.transfer(x,10000);

		println("Transferd account balance : "+m.Balance);
		println("Received account balance  : "+x.head.Balance);
	}

	val find=(accNumber:Int,list:List[account])=>list.filter(x=>x.accNumber.equals(accNumber));
}

class account(id:String,acc:Int,balance:Double)
{
	var nic=id;
	var accNumber=acc;
	var Balance=balance;

	def withdraw(amount:Double)=if(Balance>amount) Balance=Balance-amount else println("Your account balnce is not sufficient.");
	def deposit(amount:Double)=Balance=Balance+amount;
	def transfer(acc:List[account],amount:Double)=
	{
		if(Balance>amount)
		{
			Balance=Balance-amount;
			acc.head.Balance=acc.head.Balance+amount;
		}
		else
		{
			println("Your account balnce is not sufficient.");
		}
	}	
}
