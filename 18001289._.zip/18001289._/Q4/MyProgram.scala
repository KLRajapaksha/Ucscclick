object MyProgram {
	def main(args:Array[String])
	{

		var j=new account("123",2000,1000);
		var k=new account("124",3000,2000);
		var l=new account("125",4000,3000);
		var m=new account("126",5000,-1000);
		var n=new account("127",6000,-1500);
		val bank:List[account]=List(j,k,l,m,n);

		print("Overdraft accounts   : ");
		var ODlist=overdraft(bank);
		ODlist.foreach(x=>print(x.accNumber+"   "));

		var totalBalance=balance(bank);
		print("\nTotal account balance       : "+totalBalance.accountBalance);

		print("\nAccount balances + interest : ")
		var interestList=interest(bank);
		interestList.foreach(x=>print(x+" "));

	}

	val overdraft=(list:List[account])=>list.filter(x=>x.accountBalance<=0);
	val balance=(list:List[account])=>list.reduce((x,y)=>new account("0000",1000,x.accountBalance+y.accountBalance));
	val interest=(list:List[account])=>list.map(x=>(if(x.accountBalance>0) x.accountBalance*1.05d else x.accountBalance*1.01d));
}


class account(id:String,aNumber:Int,balance:Double)
{
	var nic=id;
	var accNumber=aNumber;
	var accountBalance=balance;
}
